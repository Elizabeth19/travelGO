function doItNow(xmlFile, path, resultElementId){
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			showResult(xhttp.responseXML);
		}
	};
	xhttp.open("GET", xmlFile, true);
	xhttp.send(); 

	function showResult(xml) {
		var txt = "";
		if (xml.evaluate) {
			var nodes = xml.evaluate(path, xml, null, XPathResult.ANY_TYPE, null);
			var result = nodes.iterateNext();
			while (result) {
				txt += result.childNodes[0].nodeValue + "<br>";
				result = nodes.iterateNext();
			} 
		// Code For Internet Explorer
		} else if (window.ActiveXObject || xhttp.responseType == "msxml-document") {
			xml.setProperty("SelectionLanguage", "XPath");
			nodes = xml.selectNodes(path);
			for (i = 0; i < nodes.length; i++) {
				txt += nodes[i].childNodes[0].nodeValue + "<br>";
			}
		}
		document.getElementById(resultElementId).innerHTML = txt;
	}
}

// ===============================================================================

function doItNow1() {
	var path = document.getElementById("which1").value;
	doItNow("destinations.xml", path, "score1");
}
function doItNow2() {
	var path = document.getElementById("which2").value;
	doItNow("destinations.xml", path, "score2");
}
function doItNow3() {
	var path = document.getElementById("which3").value;
	doItNow("destinations.xml", path, "score3");
}
function doItNow4() {
	var path = "destinations/holidays[allinclusive='Yes1']/name|destinations/holidays[allinclusive='Yes1']/destination|destinations/holidays[allinclusive='Yes1']/city|destinations/holidays[allinclusive='Yes1']/price|destinations/holidays[allinclusive='Yes1'] | destinations/holidays[allinclusive='Yes2']/name|destinations/holidays[allinclusive='Yes2']/destination|destinations/holidays[allinclusive='Yes2']/city|destinations/holidays[allinclusive='Yes2']/price|destinations/holidays[allinclusive='Yes2'] | destinations/holidays[allinclusive='Yes3']/name|destinations/holidays[allinclusive='Yes3']/destination|destinations/holidays[allinclusive='Yes3']/city|destinations/holidays[allinclusive='Yes3']/price|destinations/holidays[allinclusive='Yes3']";
	doItNow("destinations.xml", path, "score4");
}    



