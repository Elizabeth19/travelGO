/*
	Epilogue by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
*/

(function($) {

	skel.breakpoints({
		xlarge: '(max-width: 1680px)',
		large: '(max-width: 1280px)',
		medium: '(max-width: 980px)',
		small: '(max-width: 736px)',
		xsmall: '(max-width: 480px)',
		xxsmall: '(max-width: 360px)'
	});

	$(function() {

		var	$window = $(window),
			$body = $('body');

		// Disable animations/transitions until the page has loaded.
			$body.addClass('is-loading');

			$window.on('load', function() {
				window.setTimeout(function() {
					$body.removeClass('is-loading');
				}, 100);
			});

		// Fix: Placeholder polyfill.
			$('form').placeholder();

		// Prioritize "important" elements on medium.
			skel.on('+medium -medium', function() {
				$.prioritize(
					'.important\\28 medium\\29',
					skel.breakpoint('medium').active
				);
			});

		// Items.
			$('.item').each(function() {

				var $this = $(this),
					$header = $this.find('header'),
					$a = $header.find('a'),
					$img = $header.find('img');

				// Set background.
					$a.css('background-image', 'url(' + $img.attr('src') + ')');

				// Remove original image.
					$img.remove();

			});

	});
            // Tabs
            $(document).ready(function() {
            $('.tabs .tab-links a').on('click', function(e)  {
            var currentAttrValue = $(this).attr('href');
            
            
            $('.tabs ' + currentAttrValue).show().siblings().hide();
            
            // Change/remove current tab to active
           $(this).parent('li').addClass('active').siblings().removeClass('active');
            e.preventDefault();
                });
            });
                
            // Toggle/Slide
            $(document).ready(function(){
            $("#tog").click(function(){
            $("#menu").slideToggle(1000);
            
                });
            });
                
            // Show/Hide Tabs
            $(document).ready(function(){
            $("#hide").click(function(){
            $("p").hide();
            });
            $("#show").click(function(){
            $("p").show();
                });
            });
            
            // Message reveal    
            $(document).ready(function(){
            $("#btn1").click(function(){
            $("#Message").text("Congratulations here is your free Travel voucher code - 677584DF");
                });

            });
            
            $(document).ready(function() {
            $("#buttonmike1").click(function(){
            $("#latest1").fadeIn(2000);
                });
            });

    
            $(document).ready(function() {
            $("#buttonmike2").click(function(){
            $("#latest2").slideToggle(3000);
                });
            });

            $(document).ready(function() {
            $("#buttonmike3").click(function(){
            $("#latest3").slideDown(2000);
                });
            });
    

    
            $(document).ready(function() {
            $("#buttonmike4").click(function(){
            $("#latest4").slideToggle(2000);
                });
            });
    
            $(document).ready(function() {
            $("#hidebtn1").click(function(){
            $("#latest1").slideUp(2000).delay(500);
                });
            });

            $(document).ready(function() {
            $("#hidebtn2").click(function(){
            $("#latest2").fadeToggle(1000);
                });
            });
    
            $(document).ready(function() {
            $("#hidebtn3").click(function(){
            $("#latest3").fadeOut(1000);
                });
            });
    
            $(document).ready(function() {
            $("#hidebtn4").click(function(){
            $("#latest4").fadeOut(1000);
                });
            });


			/* Show more / less on Special Offers text */
            $(document).ready(function() {
            // Configure/customize these variables.
            var showChar = 100;  // How many characters are shown by default
            var ellipsestext = "...";
            var moretext = "Show more >";
            var lesstext = "Show less";
    

            $('.more').each(function() {
            var content = $(this).html();
 
            if(content.length > showChar) {
 
            var c = content.substr(0, showChar);
            var h = content.substr(showChar, content.length - showChar);
 
            var html = c + '<span class="moreellipses">' + ellipsestext+ '&nbsp;</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';
 
            $(this).html(html);
        }
 
    });
 
            $(".morelink").click(function(){
            if($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
            } else {
            $(this).addClass("less");
            $(this).html(lesstext);
            }
            $(this).parent().prev().toggle();
            $(this).prev().toggle();
            return false;
    });
});


















})(jQuery);